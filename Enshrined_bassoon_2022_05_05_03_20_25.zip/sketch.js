//global variable (as oppposed to a local variable with a smaller scope)
let myElip

let rect1x = 20;
let rect1y = 20;
let rect1w = 60;
let rect1h = 60;
let rect2x = 300;
let rect2y = 20;
let rect2w = 60;
let rect2h = 30;
let ellipse1x = 160
let ellipse1y = 160
let ellipse1w = 50
let ellipse1h = 75
let rect3x = 220;
let rect3y = 20;
let rect3w = 40;
let rect3h = 40;
let ellipse2x = 260
let ellipse2y = 160
let ellipse2w = 85
let ellipse2h = 85
let rect4x = 100;
let rect4y = 30;
let rect4w = 100;
let rect4h = 50;
let ellipse3x = 40;
let ellipse3y = 160;
let ellipse3w = 100;
let ellipse3h = 65;
let ellipse4x = 350;
let ellipse4y = 140;
let ellipse4w = 65;
let ellipse4h = 120;
let rect5x = 30;
let rect5y = 240;
let rect5w = 30;
let rect5h = 30;
let rect6x = 120;
let rect6y = 220;
let rect6w = 100;
let rect6h = 50;
let rect7x = 240;
let rect7y = 230;
let rect7w = 60;
let rect7h = 60;
let rect8x = 300;
let rect8y = 210;
let rect8w = 100;
let rect8h = 60;
let ellipse5x = 50;
let ellipse5y = 340;
let ellipse5w = 120;
let ellipse5h = 30;
let ellipse6x = 160;
let ellipse6y = 340;
let ellipse6w = 60;
let ellipse6h = 120;
let ellipse7x = 280;
let ellipse7y = 355;
let ellipse7w = 120;
let ellipse7h = 90;
let ellipse8x = 360;
let ellipse8y = 340;
let ellipse8w = 40;
let ellipse8h = 70;


function setup() {
  createCanvas(400, 400);// create a canvas element 400px wide and 400px tall
}

function draw() {
 background(220,140,140); //
  fill(color('turquoise'));
  rect(rect1x, rect1y, rect1w, rect1h);
fill(color('magenta'));
  ellipse(ellipse1x,ellipse1y,ellipse1w,ellipse1h);
fill(color('violet'));
  rect(rect2x, rect2y, rect2w, rect2h)
  fill(color('green'))
  ellipse(ellipse2x,ellipse2y,ellipse2w,ellipse2h)
fill(color('grey'))
  rect(rect3x, rect3y, rect3w, rect3h)
fill(color('red'))
  rect(rect4x,rect4y,rect4w,rect4h)
fill(color('pink'))
  ellipse(ellipse3x,ellipse3y,ellipse3w,ellipse3h)
fill(color('orange'))
  ellipse(ellipse4x,ellipse4y,ellipse4w,ellipse4y)
fill(color('blue'))  
  rect(rect5x,rect5y,rect5w,rect5h)
fill (color('yellow'))
  rect(rect6x,rect6y,rect6w,rect6h)
fill (color('cyan'))
  rect (rect7x,rect7y,rect7w,rect7h)
fill (color('plum'))
  rect(rect8x,rect8y,rect8w,rect8h)
fill (color('khaki'))  
  ellipse (ellipse5x,ellipse5y,ellipse5w,ellipse5h)
fill(color('gold'))  
  ellipse (ellipse6x,ellipse6y,ellipse6w,ellipse6h)
fill(color('crimson'))
  ellipse(ellipse7x,ellipse7y,ellipse7w,ellipse7h)
 fill(color('lime')) 
  ellipse(ellipse8x,ellipse8y,ellipse8w,ellipse8h)  

  if (mouseX > rect1x && mouseX < rect1x + rect1w && mouseY > rect1y && mouseY < rect1y + rect1h && mouseIsPressed){
    console.log("yes");
    rect1x = mouseX - rect1w/2;
    rect1y = mouseY - rect1h/2;
  }
if (mouseX > rect2x && mouseX < rect2x + rect2w && mouseY > rect2y && mouseY < rect2y + rect2h && mouseIsPressed){
      console.log("yes");
    rect2x = mouseX - rect2w/2;
    rect2y = mouseY - rect2h/2;
  }
if (mouseX > ellipse1x - ellipse1w/2 && mouseX < ellipse1x + ellipse1w/2 && mouseY > ellipse1y - ellipse1h/2 && mouseY < ellipse1y + ellipse1h/2 && mouseIsPressed){
  console.log("yes");
    ellipse1x = mouseX;
    ellipse1y = mouseY;
}
  if (mouseX > rect3x && mouseX < rect3x + rect3w && mouseY > rect3y && mouseY < rect3y + rect3h && mouseIsPressed){
    console.log("yes");
    rect3x = mouseX - rect3w/2;
    rect3y = mouseY - rect3h/2;
  }
if (mouseX > ellipse2x - ellipse2w/2 && mouseX < ellipse2x + ellipse2w/2 && mouseY > ellipse2y - ellipse2h/2 && mouseY < ellipse2y + ellipse2h/2 && mouseIsPressed){
  console.log("yes");
    ellipse2x = mouseX;
    ellipse2y = mouseY;
}
if (mouseX > ellipse3x - ellipse3w/2 && mouseX < ellipse3x + ellipse3w/2 && mouseY > ellipse3y - ellipse3h/2 && mouseY < ellipse3y + ellipse3h/2 && mouseIsPressed){
  console.log("yes");
    ellipse3x = mouseX;
    ellipse3y = mouseY;
}
   if (mouseX > rect4x && mouseX < rect4x + rect4w && mouseY > rect4y && mouseY < rect4y + rect4h && mouseIsPressed){
    console.log("yes");
    rect4x = mouseX - rect4w/2;
    rect4y = mouseY - rect4h/2;
   }
if (mouseX > ellipse4x - ellipse4w/2 && mouseX < ellipse4x + ellipse4w/2 && mouseY > ellipse4y - ellipse4h/2 && mouseY < ellipse4y + ellipse4h/2 && mouseIsPressed){
  console.log("yes");
    ellipse4x = mouseX;
    ellipse4y = mouseY;
}
  
   if (mouseX > rect5x && mouseX < rect5x + rect5w && mouseY > rect4y && mouseY < rect5y + rect5h && mouseIsPressed){
    console.log("yes");
    rect5x = mouseX - rect5w/2;
    rect5y = mouseY - rect5h/2;
   }
  
   if (mouseX > rect6x && mouseX < rect6x + rect6w && mouseY > rect4y && mouseY < rect6y + rect6h && mouseIsPressed){
    console.log("yes");
    rect6x = mouseX - rect6w/2;
    rect6y = mouseY - rect6h/2;
   }
   if (mouseX > rect7x && mouseX < rect7x + rect7w && mouseY > rect7y && mouseY < rect7y + rect7h && mouseIsPressed){
    console.log("yes");
    rect7x = mouseX - rect7w/2;
    rect7y = mouseY - rect7h/2;
   }
   if (mouseX > rect8x && mouseX < rect8x + rect8w && mouseY > rect8y && mouseY < rect8y + rect8h && mouseIsPressed){
    console.log("yes");
    rect8x = mouseX - rect8w/2;
    rect8y = mouseY - rect8h/2;
   }
if (mouseX > ellipse5x - ellipse5w/2 && mouseX < ellipse5x + ellipse5w/2 && mouseY > ellipse5y - ellipse5h/2 && mouseY < ellipse5y + ellipse5h/2 && mouseIsPressed){
  console.log("yes");
    ellipse5x = mouseX;
    ellipse5y = mouseY;
}
  if (mouseX > ellipse6x - ellipse6w/2 && mouseX < ellipse6x + ellipse6w/2 && mouseY > ellipse6y - ellipse6h/2 && mouseY < ellipse6y + ellipse6h/2 && mouseIsPressed){
  console.log("yes");
    ellipse6x = mouseX;
    ellipse6y = mouseY;
  }
    if (mouseX > ellipse7x - ellipse7w/2 && mouseX < ellipse7x + ellipse7w/2 && mouseY > ellipse7y - ellipse7h/2 && mouseY < ellipse7y + ellipse7h/2 && mouseIsPressed){
  console.log("yes");
    ellipse7x = mouseX;
    ellipse7y = mouseY;
    }
      if (mouseX > ellipse8x - ellipse8w/2 && mouseX < ellipse8x + ellipse8w/2 && mouseY > ellipse8y - ellipse8h/2 && mouseY < ellipse8y + ellipse8h/2 && mouseIsPressed){
  console.log("yes");
  ellipse1x = mouseX;
  ellipse1y = mouseY;
   }
}


